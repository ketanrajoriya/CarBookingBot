const path = require('path');
const restify = require('restify');
const { BotFrameworkAdapter, MemoryStorage, ConversationState, UserState } = require('botbuilder');
const { CosmosDbStorage } = require("botbuilder-azure");
const { BotConfiguration } = require('botframework-config');
const { Bot } = require('./bot');
const winston = require('winston');
const logger = winston.createLogger({
  transports: [
    new winston.transports.Console()
  ]
});
const storage = new MemoryStorage();

const conversationState = new ConversationState(storage);

// Read botFilePath and botFileSecret from .env file.
// Note: Ensure you have a .env file and include botFilePath and botFileSecret.

const ENV_FILE = path.join(__dirname, '.env');
const env = require('dotenv').config({ path: ENV_FILE });

console.log(process.env.botFilePath);
console.log("qnaKBCount" + process.env.qnaKBCount);

const qnaKBCount = process.env.qnaKBCount;

// Get the .bot file path.
const BOT_FILE = path.join(__dirname,(process.env.botFilePath || ''));
let botConfig;
let exactMatchWords;
try {
    // Read configuration from .bot file.
    botConfig = BotConfiguration.loadSync(BOT_FILE, process.env.botFileSecret);
} catch (err) {
    console.log(err);
    console.error(`\nError reading bot file. Please ensure you have valid botFilePath and botFileSecret set for your environment.`);
    console.error(`\n - The botFileSecret is available under appsettings for your Azure Bot Service bot.`);
    console.error(`\n - If you are running this bot locally, consider adding a .env file with botFilePath and botFileSecret.\n\n`);
    process.exit();
}

// For local development configuration as defined in .bot file.
const DEV_ENVIRONMENT = 'development';

// Bot name as defined in .bot file or from runtime.
// See https://aka.ms/about-bot-file to learn more about .bot files.
const BOT_CONFIGURATION = (process.env.NODE_ENV || DEV_ENVIRONMENT);

// QnA Maker service name as specified in .bot file.
const LUIS_CONFIGURATIION = "carbot";
// Get endpoint and QnA Maker configurations by service name.
const endpointConfig = botConfig.findServiceByNameOrId(BOT_CONFIGURATION);
const luisConfig = botConfig.findServiceByNameOrId(LUIS_CONFIGURATIION);


// Map the contents to the required format for `QnAMaker`
const qnaEndpointSettings = {};
const qnaConfigArray = [];

for (let i = 0; i < qnaKBCount; i++) {
    qnaConfigArray.push(botConfig.findService((i + 1).toString()));
}

const luisApplication = {
    applicationId: luisConfig.appId,
    endpointKey: luisConfig.subscriptionKey || luisConfig.authoringKey,
    endpoint: luisConfig.getEndpoint()

};
const luisPredictionOptions = {
    bingSpellCheckSubscriptionKey: process.env.CommScope_SpellCheck,
    includeAllIntents: true,
    log: true,
    spellCheck: true,
    staging: false
};
let bot;
try {
    qnaConfigArray.forEach((qnaConfig) => {
        const qnaEndpointSetting = {
            knowledgeBaseId: '4cc5d5e8-6dfa-45a9-a499-4ea28b0a95e3',
            endpointKey: '1bb2c86a-c9dd-4628-b4cf-2341ae365e40',
            host: 'https://qnaservicedemo.azurewebsites.net/qnamaker'
        };
        qnaEndpointSettings['Small Talk'] = qnaEndpointSetting;
    },
        );

    bot = new Bot(luisApplication, luisPredictionOptions, qnaEndpointSettings, {}, conversationState,storage);
} catch (err) {
    console.error(`[botInitializationError]: ${err}`);
    process.exit();
}


// Create adapter. See https://aka.ms/about-bot-adapter to learn more about adapters.
const adapter = new BotFrameworkAdapter({
    appId: '0307dd99-9129-4748-95df-9fca817f13d8'|| endpointConfig.appId || process.env.MICROSOFT_APP_ID,
    appPassword: 'k8_Hj^ETF_1)p-K%n&QK8[0gXBSj1N'|| endpointConfig.appPassword || process.env.MICROSOFT_APP_PASSWORD
});

adapter.onTurnError = async(turnContext, error) => {
    console.error(`\n [onTurnError]: ${error}`);
    await turnContext.sendActivity(`Oops. Something went wrong!`);
};

// Create HTTP server.
const server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3978,  () =>{
    console.log(`\n${server.name} listening to ${server.url}.`);
});

// Listen for incoming requests.
server.post('/api/messages',(req, res) => {
    adapter.processActivity(req, res, async(turnContext) => {
        await bot.onTurn(turnContext);
});
});

