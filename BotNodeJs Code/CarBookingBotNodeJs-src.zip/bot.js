'use strict';

const { ActivityTypes, TurnContext, MessageFactory } = require('botbuilder');
const { LuisRecognizer } = require('botbuilder-ai');
const { QnAMaker, QnAMakerEndpoint, QnAMakerOptions } = require('botbuilder-ai');
const { TextPrompt, DialogSet, WaterfallDialog } = require('botbuilder-dialogs');
 const spellCheck = require('./lib/spellCheck');
const { QnAMakerCustom } = require('./lib/qnaMakerCustom');
const winston = require('winston');
const { AzureApplicationInsightsLogger } = require('winston-azure-application-insights');
 
const TOP = 1;
const QNATHRESHOLD = 0.6;

const SUGGESTIONTEXT = "I'm not quite sure what you're asking me. I'hv made a suggestion for you below, if that's not correct, Please rephrase your question and ask me again";
const SUGGESTIONTEXTNONE = "I'm Sorry, but I'm unable to answer your question";
const WELCOME_STATEMENT = 'Welcome to the Cab booking Bot!. How can I help you today?';


// Winston logger to log information
const logger = winston.createLogger({
  transports: [
    new winston.transports.Console()
  ]
});

// Winston transporter to log information to Application Insights
winston.add(new AzureApplicationInsightsLogger({
    key: "bf285c10-010f-4745-a291-89167558dad4"
}));

let To;
let From;
let CabType;
let Date;
let Time;
/**
 * A simple bot that responds to utterances with answers from the Language Understanding (LUIS) service.
 * If an answer is not found for an utterance, the bot responds with help.
 */
class Bot {

    /**
     * The LuisBot constructor which is used to create an instance of `LuisRecognizer`.
     * @param {LuisApplication} luisApplication The basic configuration needed to call LUIS. In this sample the configuration is retrieved from the .bot file.
     * @param {LuisPredictionOptions} luisPredictionOptions (Optional) Contains additional settings for configuring calls to LUIS.
     * @param {QnAMakerEndpoint} qnaEndpoint The basic configuration needed to call QnA Maker. In this sample the configuration is retrieved from the .bot file.
     * @param {QnAMakerOptions} config     
     */
    constructor(application, luisPredictionOptions, qnaEndpoint, config, conversationState, storage) {
        this.luisRecognizer = new LuisRecognizer(application, luisPredictionOptions, true);
        this.intentKeys = Object.keys(qnaEndpoint);
        this.qnaMaker = {};
        this.intentKeys.forEach((element) => {
            this.qnaMaker[element] = new QnAMakerCustom(qnaEndpoint[element]);
        });
        this.conversationState = conversationState;
        this.storage = storage;
    }
    
    /**
     * sendSuggestedActions used to send city suggestions to user.
     * @param {turnContext} turnContext Contains all the data needed for processing the conversation turn.
     * @param {country} country for which the prompts should  display.
     * 
     */
    async sendSuggestedActions(turnContext, country) {
    const reply = MessageFactory.suggestedActions(COUNTRY_CITY_MAPPING[country], COUNTRY_SUGGESTION_PROMPT);
    await turnContext.sendActivity(reply);
}

/**
 * Every conversation turn calls this method.
 * @param {TurnContext} turnContext Contains all the data needed for processing the conversation turn.
 */
async onTurn(turnContext) {

    if (turnContext.activity.type === ActivityTypes.Message) {
        console.log("Before spellCheck:" +turnContext.activity.text);
        //Spell check
        turnContext.activity.text = await spellCheck(turnContext.activity.text);
        //Luis recognizer
                console.log("After spellCheck:" +turnContext.activity.text);
        // console.log("topIntent:" + JSON.stringify(results));        
        let results = await this.luisRecognizer.recognize(turnContext);
        console.log(" LUIS results"+results);
        results = results.luisResult;
                
        console.log("topIntent:" + JSON.stringify(results));
        const topScoringIntent = results.topScoringIntent.intent;
        console.log("Cab details");
                console.log(`From: ${From} To: ${To} CabType:${CabType} Date: ${Date} Time ${Time}`);
                let entityValue = results.entities[0];
        if (topScoringIntent !== 'None') {
            console.log("topIntent.intent:----"+topScoringIntent);
            console.log(":----"+JSON.stringify(results.entities));
            if(topScoringIntent == 'BookCab'){
            logger.info('Inside Book cab intent');
            console.log(":----"+JSON.stringify(results.entities));
                let entities = results.entities;

                for(let i = 0; i < entities.length; i++){
                    if(entities[i].type ==='To'){
                       To =  entities[i].entity;
                    }
                    if(entities[i].type ==='From'){
                       From =  entities[i].entity;
                    }
                    if(entities[i].type ==='CabType'){
                       CabType =  entities[i].entity;
                    }
                    if(entities[i].type ==='builtin.datetimeV2.date'){
                       Date =  entities[i].entity;
                    }
                    console.log("entities:----"+entities[i]);
                }
                if(From && To && CabType && Date){
                return await turnContext.sendActivity(`your ${CabType} cab is confirmed ${From} to ${To} on ${Date}`);                    
                }
                if(!From){
               return await turnContext.sendActivity("From where are you traveling?");                    
                }
                if(!To){
                return await turnContext.sendActivity("To where are you traveling?");                    
                }
                if(!CabType){
                    return await turnContext.sendActivity("What kind of cab you want?");
                }
                if(!Date){
                    return await turnContext.sendActivity("When are you leaving?");
                }
        
            } else if(topScoringIntent == 'Address'){
                logger.info('Inside Address intent');

                if(!From){
                    From = entityValue.entity
                return await turnContext.sendActivity("To where are you traveling?"); 
                } else {
                    To = entityValue.entity                              
                return await turnContext.sendActivity("What kind of cab you want?"); 
                }
            }
            else if(topScoringIntent == 'CabTypeintent'){
                logger.info('Inside CabTypeintent intent');
                CabType = entityValue.entity                              
                return await turnContext.sendActivity("When are you leaving?");                
            }
            else if(topScoringIntent == 'Time'){
                logger.info('Inside Time intent');
                if(From && To && CabType){
                    Date = entityValue.entity
                 return await turnContext.sendActivity(`your ${CabType} cab is confirmed ${From} to ${To} on ${Date}`);
                } else {
                return await turnContext.sendActivity(SUGGESTIONTEXTNONE);
                }
            } 
         else if(topScoringIntent == 'Cancel'){
            logger.info('Inside Time intent');
            await turnContext.sendActivity("Your cab is canceled!")
        } 
}
        else {
            const qnaSmallTalkResults = await this.qnaMaker["Small Talk"].generateAnswer(turnContext.activity.text, TOP, QNATHRESHOLD);

            if (qnaSmallTalkResults[0]) {
                await turnContext.sendActivity(qnaSmallTalkResults[0].answer);
            } else {
                await turnContext.sendActivity(SUGGESTIONTEXTNONE);
            }
        }
    } else if (turnContext.activity.type === ActivityTypes.ConversationUpdate && turnContext.activity.recipient.id === turnContext.activity.membersAdded[0].id) {
                logger.info('Inside Conversation update');  
        const reply = MessageFactory.suggestedActions(['Book a cab'], WELCOME_STATEMENT);
        await turnContext.sendActivity(reply);
    } else if (turnContext.activity.type === ActivityTypes.Typing) {
    } else if (turnContext.activity.type !== ActivityTypes.ConversationUpdate) {
    }

}
}

module.exports.Bot = Bot;